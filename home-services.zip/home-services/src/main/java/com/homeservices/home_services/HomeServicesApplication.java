package com.homeservices.home_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeServicesApplication.class, args);
	}

}
